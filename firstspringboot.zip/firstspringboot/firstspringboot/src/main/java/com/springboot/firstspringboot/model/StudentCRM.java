package com.springboot.firstspringboot.model;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
@Getter
@Setter
public class StudentCRM {

    private int id;

    private String rollNr;

    @NotEmpty(message = "Empty not allowed")

    private String name;

    private char gender;


    public StudentCRM() {

    }

}
