package com.springboot.firstspringboot.controller;

import com.springboot.firstspringboot.service.StudentService;
import com.springboot.firstspringboot.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@Controller
public class StudentController {

    @Autowired
    StudentService studentService;


    @GetMapping("/")
    public String showStudent(Model model) {


        model.addAttribute("student", new Student());

        return "student";
    }

    @PostMapping("/saveUser")
    public String saveUser(@Valid @ModelAttribute("student") Student student, BindingResult binding,
                           Model model)
    {
        if (binding.hasErrors())
        {
            return "student";
        }

        studentService.save(student);

        return "success";

    }

}
