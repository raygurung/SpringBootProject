package com.springboot.firstspringboot.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Getter
@Setter
@NoArgsConstructor


public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String rollNr;
    @NotEmpty(message = "Empty not allowed")
    private String name;
    private char gender;

    public Student(String rollNr, String name, char gender) {
        this.rollNr = rollNr;
        this.name = name;
        this.gender = gender;
    }
}