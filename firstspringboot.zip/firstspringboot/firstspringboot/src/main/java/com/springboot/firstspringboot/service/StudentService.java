package com.springboot.firstspringboot.service;

import com.springboot.firstspringboot.model.Student;

public interface StudentService {

    public void save(Student student);
    public Student findStudentById(int id);


}
